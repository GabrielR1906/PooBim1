package Universidad;

import Ejecutor.Ejecutor;

public class Universidad {

    Ejecutor ejecutor = new Ejecutor();
//-----------------------------------------------------------------------------
    private double m1;
    private double m2;
    private double m3;
    String dato;
    double promedio;
    String nombre = "Juan Universidad";
    String direccion = "18 de noviembre";
//-------------------------------------------------------------------------------
    public Universidad() {
        m1 = 0;
        m2 = 0;
        m3 = 0;
    }
    public Universidad(double m1, double m2, double m3) {
        double materia1 = m1;
        double materia2 = m2;
        double materia3 = m3;
    }
//------------------------------------------------------------------------------
    public double getM1() {
        return m1;
    }
    public void setM1(double materia1) {
        this.m1 = materia1;
    }
    public double getM2() {
        return m2;
    }
    public void setM2(double materia2) {
        this.m2 = materia2;
    }
    public double getM3() {
        return m3;
    }
    public void setM3(double materia3) {
        this.m3 = materia3;
    }
//----------------------------------------------------------------------------------
    public double ObtenerPromedio(){
        promedio = (m1+m2+m3)/3;
        return promedio;
    }
    public String Datos(){
        dato = "El nombre de la universidad es: "+nombre+"\n"+"La direccion de la universidad es: "+direccion;
        return dato;
    }
}
