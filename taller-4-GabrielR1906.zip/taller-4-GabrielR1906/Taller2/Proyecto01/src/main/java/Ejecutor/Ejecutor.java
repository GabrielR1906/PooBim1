package Ejecutor;

import Universidad.Universidad;

public class Ejecutor {

    public static void main(String[] args) {
        Universidad u = new Universidad();
        
        double materia1 = 10;
        double materia2 = 9;
        double materia3 = 9;
        
        u.setM1(materia1);
        u.setM2(materia2);
        u.setM3(materia3);
        
        System.out.println("--------------------------------------------------------------------------------------------------------------");
        System.out.println(u.Datos());
        System.out.println("La calificacion de la materia 1 es: "+materia1);
        System.out.println("La calificacion de la materia 2 es: "+materia2);
        System.out.println("La calificacion de la materia 2 es: "+materia2);
        System.out.println("El promedio de calificacion es: "+u.ObtenerPromedio());
        System.out.println("--------------------------------------------------------------------------------------------------------------");
    }

}
