package Ejecutor;

import Fabricante.Fabricante;
import Fabricante.Matricula;

public class Ejecutor {

    public static void main(String[] args) {
        Fabricante f = new Fabricante();
        Matricula m = new Matricula();

        String cedula = "1102726377";
        int año = 2010;
        double valor = 10000;

        m.setAño(año);
        m.setPrecio(valor);
        System.out.println("El numero de cedula es "+cedula);
        System.out.println("El año del vehiculo es: "+año);
        System.out.println("El valor del vehiculo es: "+valor);
        System.out.println("El valor de la matricula es: "+m.ObtenerValor());
        System.out.println(f.mensaje());
    }

}
