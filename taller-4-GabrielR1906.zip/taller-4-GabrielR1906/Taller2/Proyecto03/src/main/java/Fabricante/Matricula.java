package Fabricante;

public class Matricula {

    private int añoactual = 2023;
    private double iva = 0.002;
    private int año;
    private double precio;

    public Matricula(){
        año = 0;
        precio = 0;
    }
    public double getPrecio() {
        return precio;
    }
    public void setPrecio(double precio) {
        this.precio = precio;
    }
    public int getAño() {
        return año;
    }
    public void setAño(int año) {
        this.año = año;
    }
    public int getAñoactual() {
        return añoactual;
    }
    public void setAñoactual(int añoactual) {
        this.añoactual = añoactual;
    }
    public double getIva() {
        return iva;
    }
    public void setIva(double iva) {
        this.iva = iva;
    }

   public double ObtenerValor(){
       iva = iva*precio;
       año = añoactual-año;
       precio = iva+año;
       return precio;
   }
}
