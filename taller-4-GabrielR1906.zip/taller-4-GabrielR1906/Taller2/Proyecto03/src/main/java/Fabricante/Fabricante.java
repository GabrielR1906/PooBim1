
package Fabricante;
public class Fabricante {
     private String fabricante="Toyota";
     private String ciudad = "Miami";
     String mensaje;
     int numero;
     public Fabricante(){
         numero=0;
     }
     public String mensaje(){
         mensaje = "El fabricante es: "+fabricante+"\n"+"La ciudad de origen es "+ciudad;
         return mensaje;
     }
}
