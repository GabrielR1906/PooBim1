
package Ejecutor;
import Provincia.Provincia;
import Provincia.Sueldo;
public class Ejecutor {
    public static void main(String[] args) {
        Provincia p = new Provincia();
        Sueldo s = new Sueldo();
        
        String nombre = "Juan";
        String apellido = "Garcia";
        double sueldobasico = 450;
        
        s.setSueldo(sueldobasico);
        
        System.out.println("El nombre de la persona es: "+nombre+" "+apellido);
        System.out.println("El sueldo basico es: "+sueldobasico);
        System.out.println("El suelto total es: "+s.ObtenerSueldoFinal());
        System.out.println(p.ObtenerProvincia() );
    }
    
}
