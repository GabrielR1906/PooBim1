
package Provincia;
public class Provincia {
    String nombre = "Loja";
    int cantidad = 500;
    String mensaje;
    
    public Provincia(){
        mensaje = "";
    }
    public String ObtenerProvincia(){
        mensaje = "El nombre de la provincia es: "+nombre+"\n"+"La cantidad de habitantes es: "+cantidad;
        return mensaje;
    }
}
