package Provincia;

public class Sueldo {

    Double iva = 0.20;
    double sueldo;
    double sueldofinal;

        public Sueldo() {
            sueldofinal = 0;
            sueldo = 0;
    }
        
    public double getSueldo() {
        return sueldo;
    }

    public void setSueldo(double sueldo) {
        this.sueldo = sueldo;
    }

    public double ObtenerSueldoFinal() {
        iva = sueldo*iva;
        sueldofinal = sueldo+iva;
        return sueldofinal;

    }
}
