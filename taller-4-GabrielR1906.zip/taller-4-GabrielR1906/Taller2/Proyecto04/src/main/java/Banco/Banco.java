
package Banco;

public class Banco {
    String nombre = "BancoJuan";
    int sucursales = 5;
    double comision;
   private   double valorcheque;

    public double getValorcheque() {
        return valorcheque;
    }
    public void setValorcheque(double valorcheque) {
        this.valorcheque = valorcheque;
    }
    
    String mensaje;
    public Banco(){
        valorcheque =0;
        mensaje = "";
    }
    public double Comision(){
        comision = valorcheque*0.003;
        return comision;
    }
    public String ObtenerBanco(){
        mensaje = "El nombre del banco es: "+nombre+"\n"+"Numero de sucursales es: "+sucursales;
        return mensaje;
    }
}
