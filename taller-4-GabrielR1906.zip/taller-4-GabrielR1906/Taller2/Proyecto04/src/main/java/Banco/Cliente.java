
package Banco;

public class Cliente {
    String nombre = "Juan";
    String apellido = "Garcia";
    String cedula = "1106050709";
    String mensaje;
    
    public Cliente(){
        mensaje = "";
    }
    
    public String ObtenerCliente(){
        mensaje = "Nombre del cliente: "+nombre+" "+apellido+"\n"+"El numero de cedula es: "+cedula;
        return mensaje;
    }
}
