package Ejecutor;
import Banco.Banco;
import Banco.Cliente;
public class Ejecutor {

    public static void main(String[] args) {
        Banco b = new Banco();
        Cliente c = new Cliente();
        
       double valorcheque = 1200;
        b.setValorcheque(valorcheque);
        
        System.out.println(b.ObtenerBanco());
        System.out.println("La comision del banco es "+b.Comision());
        System.out.println("El valor del cheque es "+valorcheque);
        System.out.println(c.ObtenerCliente());
        
    }
    
}
