
package Ejecutor;

import Vehiculo.Vehiculo;

public class Ejecutor {

    public static void main(String[] args) {

        Vehiculo v = new Vehiculo();
        Vehiculo v1 = new Vehiculo();

        String cedula = "1102726377";
        String marca = "Toyota";
        int añoFabricacion = 2010;
        double valorVehiculo = 10000;

        v.setCedula(cedula);
        v.setMarca(marca);
        v.setAñoFabricacion(añoFabricacion);
        v1.setValorVehiculo(valorVehiculo);

        
        System.out.println("La cedula del propietario es: "
                + v.getCedula());
        System.out.println("La marca del vehiculo es: " + v.getMarca());
        System.out.println("El año de fabricacion es: " + v.getAñoFabricacion());
        System.out.println("El valor del vehiculo es: "
                + v1.getValorVehiculo());
        System.out.println("Los años de antigüedad del vehiculo son: "
                + v.ObtenerAño());
        System.out.println("El costo de la matricula es: "
                + v1.ObtenerValorMatricula());
    }

}
