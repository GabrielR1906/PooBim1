
package Vehiculo;


public class Vehiculo {

    private String cedula;
    private String marca;
    private int añoFabricacion;
    private double valorVehiculo;
    private double valorMatricula;
    private int año = 2023;

    //Contructor 1
    
    public Vehiculo() {

        cedula = "";
        marca = "";
        añoFabricacion = 0;
        valorVehiculo = 0;
        valorMatricula = 0;;
    }

    //Constructor 2
    
    public Vehiculo(String cedu, String mar, int aF, double valorV,
            double valorM) {
        cedula = cedu;
        marca = mar;
        añoFabricacion = aF;
        valorVehiculo = valorV;
        valorMatricula = valorM;
    }
    
    //Metodos

    public String getCedula() {
        return cedula;
    }

    public void setCedula(String ced) {
        cedula = ced;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String mark) {
        marca = mark;
    }

    public int getAñoFabricacion() {
        return añoFabricacion;
    }

    public void setAñoFabricacion(int aF) {
        añoFabricacion = aF;
    }

    public double getValorVehiculo() {
        return valorVehiculo;
    }

    public void setValorVehiculo(double valorV) {
        valorVehiculo = valorV;
    }

    public double getValorMatricula() {
        return valorMatricula;
    }

    public void setValorMatricula(double valorM) {
        valorMatricula = valorM;
    }

    
    public int ObtenerAño() {
        año = año - añoFabricacion;
        return año;
    }

    public double ObtenerValorMatricula() {
        valorMatricula = (valorVehiculo * 0.00002) * año;
        return valorMatricula;
    }
}
