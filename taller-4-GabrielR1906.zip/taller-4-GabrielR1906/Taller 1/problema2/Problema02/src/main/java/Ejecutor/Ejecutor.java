
package Ejecutor;

import Profesor.profesor;

public class Ejecutor {

    public static void main(String[] args) {

        profesor p = new profesor();
        profesor p1 = new profesor();
        
        String nombre = "Gabriel";
        String apellido = "Rojas";
        double sueldoBasico = 600;
        String cedula = "1150238135";
        
        p.setNombre(nombre);
        p.setApellido(apellido);
        p.setCedula(cedula);
        p1.setSueldoBasico(sueldoBasico);
        
        System.out.println("Profesor:");
        System.out.println("Nombre: " + p.getNombre());
        System.out.println("Apellido: " + p.getApellido());
        System.out.println("Sueldo Basico: " + p1.getSueldoBasico());
        System.out.println("Sueldo Total: " + p1.obtenerSueldoTotal());
        System.out.println("Cedula: " + p.getCedula());
    }
    
}
