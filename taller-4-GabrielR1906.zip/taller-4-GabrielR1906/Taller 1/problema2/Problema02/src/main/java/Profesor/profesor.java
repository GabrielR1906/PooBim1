
package Profesor;

public class profesor {
    private String nombre;
    private String apellido;
    private double sueldoBasico;
    private double sueldoTotal;
    private String cedula;
    
    // Constructor 1
    
    public profesor(){
        nombre = "";
        apellido = "";
        //sueldoBasico = 0;
        //sueldoTotal = 0;
        cedula = "";
    }
    
    //Cosntructor 2
    
    public profesor(String nom, String ape, double sueldoB,
            double sueldoT, String cedu){
        nombre = nom;
        apellido = ape;
        sueldoBasico = sueldoB;
        sueldoTotal = sueldoT;
        cedula = cedu;
    }

    //Metodos
    
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nom) {
        nombre = nom;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String ape) {
        apellido = ape;
    }

    public double getSueldoBasico() {
        return sueldoBasico;
    }

    public void setSueldoBasico(double sueldoB) {
        sueldoBasico = sueldoB;
    }

    public double getSueldoTotal() {
        return sueldoTotal;
    }

    public void setSueldoTotal(double sueldoT) {
        sueldoTotal = sueldoT;
    }

    public String getCedula() {
        return cedula;
    }

    public void setCedula(String ced) {
        cedula = ced;
    }
    
    
    public double obtenerSueldoTotal() {
        sueldoTotal = (sueldoBasico * 0.2 ) + sueldoBasico;
        return sueldoTotal;
    }
}
