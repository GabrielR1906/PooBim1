
package Ejecutor;

import Cheque.Cheque;

public class Ejecutor {

    public static void main(String[] args) {
        // TODO code application logic here
        Cheque c = new Cheque();
        Cheque c1 = new Cheque();
        
        String nombreCliente = "Pedro";
        String nombreBanco = "BancoCiudad";
        double valorCheque = 340;
        
        c.setNombreCliente(nombreCliente);
        c.setNombreBanco(nombreBanco);
        c1.setValorCheque(valorCheque);
        
        System.out.println("El nombre del clientes es: "
                + c.getNombreCliente());
        System.out.println("El nombre del banco es: " + c.getNombreBanco());
        System.out.println("El monto del cheque es: " + c1.getValorCheque());
        System.out.println("La comision del banco es: "
                + c1.ObtenerComision());
    }
    
}
