
package Cheque;

public class Cheque {
    private String nombreCliente;
    private String nombreBanco;
    private double valorCheque;
    private double comisionBanco;
    
    //Contructor 1
    
    public Cheque(){
        nombreCliente = "";
        nombreBanco = "";
        valorCheque = 0;
        comisionBanco = 0;
    }
    
    //Contructor 2
    
    public Cheque(String nombreC, String nombreB, double valorC,
            double comisionB){
        nombreCliente = nombreC;
        nombreBanco = nombreB;
        valorCheque = valorC;
        comisionBanco = 0;
    }

    public String getNombreCliente() {
        return nombreCliente;
    }

    public void setNombreCliente(String nombreC) {
        nombreCliente = nombreC;
    }

    public String getNombreBanco() {
        return nombreBanco;
    }

    public void setNombreBanco(String nombreB) {
        nombreBanco = nombreB;
    }

    public double getValorCheque() {
        return valorCheque;
    }

    public void setValorCheque(double valorC) {
        valorCheque = valorC;
    }

    public double getComisionBanco() {
        return comisionBanco;
    }

    public void setComisionBanco(double comisionB) {
        comisionBanco = comisionB;
    }
    
    
    public double ObtenerComision() {
        comisionBanco = valorCheque * 0.00003;
        return comisionBanco;
    }
}
