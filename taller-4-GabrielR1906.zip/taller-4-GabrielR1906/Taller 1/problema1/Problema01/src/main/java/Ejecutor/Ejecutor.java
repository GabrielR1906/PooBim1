
package Ejecutor;

import Alumno.alumno;


public class Ejecutor {


    public static void main(String[] args) {

        alumno a = new alumno();
        
        double nota1 = 10;
        double nota2 = 9;
        double nota3 = 9.5;
        String nombre = "Gabriel";
        
        a.setNota1(nota1);
        a.setNota2(nota2);
        a.setNota3(nota3);
        
        alumno a1 = new alumno();
        a1.setNombre(nombre);
        
        System.out.println("Datos del estudiante:");
        System.out.println("Nombre del estudiante: " + a1.getNombre());
        System.out.println("Calificacion1: " + a.getNota1());
        System.out.println("Calificacion2: " + a.getNota2());
        System.out.println("Calificacion3: " + a.getNota3());
        System.out.println("El promedio es: " + a.obtenerPromedio());
    }
    
}
