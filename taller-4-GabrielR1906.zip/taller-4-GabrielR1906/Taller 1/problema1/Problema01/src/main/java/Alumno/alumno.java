package Alumno;

/**
 *
 * @author Gabriel
 */
public class alumno {
     private String nombre;
     private double nota1;
     private double nota2;
     private double nota3;
     private double promedio;
     
     //Constructor 1
     
     public alumno(){
         nombre = "";
         nota1 = 0;
         nota2 = 0;
         nota3 = 0;
         promedio = 0;
     }
     
     //Constructor 2
     
     public alumno(String nom, double n1, double n2, double n3, double pr){
         nombre = nom;
         nota1 = n1;
         nota2 = n2;
         nota3 = n3;
         promedio = pr;
     }
     
     //Metodos

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String n) {
        nombre = n;
    }

    public double getNota1() {
        return nota1;
    }

    public void setNota1(double no1) {
        nota1 = no1;
    }

    public double getNota2() {
        return nota2;
    }

    public void setNota2(double no2) {
        nota2 = no2;
    }

    public double getNota3() {
        return nota3;
    }

    public void setNota3(double no3) {
        nota3 = no3;
    }

    public double getPromedio() {
        return promedio;
    }

    public void setPromedio(double pro) {
        promedio = pro;
    }
    
    
    public double obtenerPromedio(){
        promedio = (nota1 + nota2 + nota3) / 3;
    return promedio;    
    }
}
