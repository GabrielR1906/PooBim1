/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.problema08;

/**
 *
 * @author renat
 */
public class Cuadrado {
    public int obtenerCuadrado(int arr1){
        return arr1*arr1;
    }
}
